package com.example.Project_team_5.Controller;

import com.example.Project_team_5.Model.Property_T5;
import com.example.Project_team_5.Service.PropertyServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/Property_T5")
public class Property_T5Controller {

    @Autowired
    private PropertyServiceInterface propertyService;

    // Endpoint to check if the service is working
    @GetMapping("/status")
    public String fun() {
        return "Working";
    }

    // Get all properties
    @GetMapping
    public List<Property_T5> getAllProperties() {
        return propertyService.getAllProperties();
    }

    // Get a property by ID
    @GetMapping("/{id}")
    public Property_T5 getPropertyById(@PathVariable Long id) {
        return propertyService.getPropertyById(id);
    }

    // Create a new property
    @PostMapping
    public Property_T5 createProperty(@RequestBody Property_T5 property) {
        return propertyService.createProperty(property);
    }

    // Update an existing property
    @PutMapping("/{id}")
    public Property_T5 updateProperty(@PathVariable Long id, @RequestBody Property_T5 propertyDetails) {
        return propertyService.updateProperty(id, propertyDetails);
    }

    // Delete a property
    @DeleteMapping("/{id}")
    public void deleteProperty(@PathVariable Long id) {
        propertyService.deleteProperty(id);
    }
}
