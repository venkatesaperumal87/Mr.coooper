
package com.example.Project_team_5.Service;

        import com.example.Project_team_5.Model.Property_T5;
        import com.example.Project_team_5.Repository.Property_T5Repository;
        import org.springframework.beans.factory.annotation.Autowired;
        import org.springframework.stereotype.Service;

        import java.util.ArrayList;
        import java.util.List;
        import java.util.Optional;

@Service
public class PropertyServiceImplementation implements PropertyServiceInterface {

    @Autowired
    private Property_T5Repository propertyT5Repository;

    public PropertyServiceImplementation(Property_T5Repository propertyT5Repository) {
        this.propertyT5Repository = propertyT5Repository;
    }

    @Override
    public List<Property_T5> getAllProperties() {
        List<Property_T5> properties = new ArrayList<>();
        propertyT5Repository.findAll().forEach(properties::add);
        return properties;
    }

    @Override
    public Property_T5 getPropertyById(Long id) {
        return propertyT5Repository.findById(id).orElse(null);
    }

    @Override
    public Property_T5 createProperty(Property_T5 property) {
        return propertyT5Repository.save(property);
    }

    @Override
    public Property_T5 updateProperty(Long id, Property_T5 propertyDetails) {
        Optional<Property_T5> optionalProperty = propertyT5Repository.findById(id);
        if (optionalProperty.isPresent()) {
            Property_T5 property = optionalProperty.get();
            property.setOwnerId(propertyDetails.getOwnerId());
            property.setPropertyName(propertyDetails.getPropertyName());
            property.setPropertyType(propertyDetails.getPropertyType());
            property.setLocation(propertyDetails.getLocation());
            property.setStatus(propertyDetails.getStatus());
            property.setDocument(propertyDetails.getDocument());
            property.setAmount(propertyDetails.getAmount());
            property.setDate(propertyDetails.getDate());
            return propertyT5Repository.save(property);
        }
        return null;
    }

    @Override
    public void deleteProperty(Long id) {
        propertyT5Repository.deleteById(id);
    }
}


