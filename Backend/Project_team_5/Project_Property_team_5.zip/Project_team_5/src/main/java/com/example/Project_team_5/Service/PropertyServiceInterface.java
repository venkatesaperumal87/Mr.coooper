package com.example.Project_team_5.Service;

import com.example.Project_team_5.Model.Property_T5;
import java.util.List;

public interface PropertyServiceInterface {
    List<Property_T5> getAllProperties();
    Property_T5 getPropertyById(Long id);
    Property_T5 createProperty(Property_T5 property);
    Property_T5 updateProperty(Long id, Property_T5 propertyDetails);
    void deleteProperty(Long id);
}

