package com.example.Project_team_5;

import org.springframework.boot.SpringApplication;

public class TestProjectTeam5Application {

	public static void main(String[] args) {
		SpringApplication.from(ProjectTeam5Application::main).with(TestcontainersConfiguration.class).run(args);
	}

}
